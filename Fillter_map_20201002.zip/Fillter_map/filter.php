
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	<form>
		<select id="id_profile_field_KV">
			<option value>Chọn vùng</option>
			<option value="Miền bắc" selected>Miền Bắc</option>
			<option value="Miền Trung">Miền Trung</option>
			<option value="Miền nam">Miền Nam</option>
			<option value="Tây Nguyên">Tây Nguyên</option>
		</select>
		<select name="profile_field_TTP" id="id_profile_field_province">
			<option value>chọn tỉnh</option>
			<option  value="Tỉnh Cao Bằng" selected>Tỉnh Cao Bằng</option>
			<option>chọn bắc</option>
		</select>
		<select name="profile_field_QH" id="id_profile_field_District">
			<option  value>chọn huyện</option>
			<option value="Thành phố Cao Bằng" selected>Thành phố Cao Bằng</option>
			<option>chọn huyện</option>
		</select>
		<select name="profile_field_X" id="id_profile_field_Communes">
			<option  value>chọn xã</option>
			<option value="Phường Sông Hiến" >Phường Sông Hiến</option>
		</select>
	</form>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="filter.js"></script>
	

</body>
</html>