$(document).ready(function(){
	$(document).on('change', '#id_profile_field_KV', function() {
		var mien = $("#id_profile_field_KV :selected").text();
		$.ajax({
			type: "POST",
			url: "data_fill.php",
			data:{mien:mien},
			cache: false,
			success:function(result){
				$('#id_profile_field_province').html(result);
			}
		});
	});

	if($("#id_profile_field_KV :selected").val() != ""){
		var mien = $("#id_profile_field_KV :selected").text();
		var nametinh = $("#id_profile_field_province :selected").val();
		$.ajax({
			type: "POST",
			url: "data_fill.php",
			data:{mien:mien, nametinh:nametinh},
			cache: false,
			success:function(result){
				$('#id_profile_field_province').html(result);
			}
		});
	}

	$(document).on('change', '#id_profile_field_province', function() {
		var selectedValue =  $("#id_profile_field_province :selected");
		var idtinh = selectedValue.data("id");
		var checkkv=$("#id_profile_field_KV :selected").val();
		if(checkkv ==""){
			alert("Bạn chưa chọn khu vực");
		}else{
			$.ajax({
				type: "POST",
				url: "data_fill.php",
				data:{idtinh:idtinh},
				cache: false,
				success:function(result){
					$('#id_profile_field_District').html(result);
				}
			});
		}
	});
	if($("#id_profile_field_province :selected").val() != "" && $("#id_profile_field_KV :selected").text() != ""){
		var selectedValue =  $("#id_profile_field_province :selected");
		var idtinh = selectedValue.data("id");
		var namehuyen = $("#id_profile_field_District :selected").val();
		$.ajax({
			type: "POST",
			url: "data_fill.php",
			data:{idtinh:idtinh, namehuyen:namehuyen},
			cache: false,
			success:function(result){
				$('#id_profile_field_District').html(result);
			}
		});
	}
	$(document).on('change', '#id_profile_field_District', function() {
		var selectedValue =  $("#id_profile_field_District :selected");
		var idhuyen = selectedValue.data("id");
		var checkkv=$("#id_profile_field_KV :selected").val();
		var checktinh =$("#id_profile_field_province :selected").val();
		if(checkkv =="" || checktinh == ""){
			alert('Bạn chưa chọn khu vực hoặc tỉnh.');
		}else{
			$.ajax({
				type: "POST",
				url: "data_fill.php",
				data:{idhuyen:idhuyen},
				cache: false,
				success:function(result){
					$('#id_profile_field_Communes').html(result);
				}
			});

		}		
	});
	$(document).on('change', '#id_profile_field_Communes', function() {
		var checkkv=$("#id_profile_field_KV :selected").val();
		var checktinh =$("#id_profile_field_province :selected").val();
		var checkhuyen=$("#id_profile_field_District :selected").val();
		if(checkkv =="" || checktinh == "" || checkhuyen ==""){
			alert('Bạn chưa chọn khu vực, tỉnh hoặc huyện.');
		}
	});
});