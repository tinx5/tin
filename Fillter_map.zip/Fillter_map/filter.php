<?php
// $mienbac = ['01','02',"04","06","08","10","11","12","14","15","17","19","20","22","24","25","26","27","30","31","33","34","35","36","37","38","40","42"];
// $mientrung=["44","45","46","48","49","51","52","54","56","58","60"];
// $taynguyen=["62","64","66","67"];
// $miennam=["68","70","72","74","75","77","79","80","82","83","84","86","87","89","91","92","93","94","95","96"];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	<form>
		<select id="id_profile_field_KV">
			<option value>Chọn vùng</option>
			<option value="Miền bắc">Miền Bắc</option>
			<option value="Miền Trung">Miền Trung</option>
			<option value="Miền nam">Miền Nam</option>
			<option value="Tây Nguyên">Tây Nguyên</option>
		</select>
		<select name="profile_field_TTP" id="id_profile_field_province">
			<option value>chọn tỉnh</option>
			<option   data-id="001" value="Tỉnh Hà Giang">Tỉnh Hà Giang</option>
			<option>chọn bắc</option>
		</select>
		<select name="profile_field_QH" id="id_profile_field_District">
			<option  value>chọn huyện</option>
			<option value="Quận Ba Đình">Quận Ba Đình</option>
			<option>chọn huyện</option>
		</select>
		<select name="profile_field_X" id="id_profile_field_Communes">
			<option  value>chọn xã</option>
			<option value="Phường Phúc Xá">Phường Phúc Xá</option>
		</select>
	</form>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="filter.js"></script>
	

</body>
</html>