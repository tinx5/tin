<?php if (!defined('IN_SITE')) die ('The request not found'); ?>
<?php include_once('widgets/header.php'); ?>
<h1>Chào mừng bạn đến với trang quản trị admin </h1>
<?php include_once('widgets/footer.php'); ?>