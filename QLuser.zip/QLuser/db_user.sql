-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th9 17, 2019 lúc 09:32 AM
-- Phiên bản máy phục vụ: 10.3.16-MariaDB
-- Phiên bản PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `db_user`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` tinyint(1) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `email`, `fullname`, `level`, `add_date`) VALUES
(2, 'tinhoang', '2cb1b780138bc273459232edda0e4b96', 'tin@gmail.com', 'Hoàng Tín', 1, NULL),
(3, 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 'tin@gmail.com', 'tin tin', 1, NULL),
(4, 'User3', '83617175fd8cf470d4af657a28def98e', 'User3@gmail.com', 'User3 Name', 2, NULL),
(6, 'User5', '83617175fd8cf470d4af657a28def98e', 'User5@gmail.com', 'User5 Name', 2, NULL),
(7, 'User6', '83617175fd8cf470d4af657a28def98e', 'User6@gmail.com', 'User6 Name', 2, NULL),
(8, 'User7', '83617175fd8cf470d4af657a28def98e', 'User7@gmail.com', 'User7 Name', 2, NULL),
(9, 'User8', '83617175fd8cf470d4af657a28def98e', 'User8@gmail.com', 'User8 Name', 2, NULL),
(10, 'User9', '83617175fd8cf470d4af657a28def98e', 'User9@gmail.com', 'User9 Name', 2, NULL),
(11, 'User10', '83617175fd8cf470d4af657a28def98e', 'User10@gmail.com', 'User10 Name', 2, NULL),
(12, 'User11', '83617175fd8cf470d4af657a28def98e', 'User11@gmail.com', 'User11 Name', 2, NULL),
(13, 'User12', '83617175fd8cf470d4af657a28def98e', 'User12@gmail.com', 'User12 Name', 2, NULL),
(14, 'User13', '83617175fd8cf470d4af657a28def98e', 'User13@gmail.com', 'User13 Name', 2, NULL),
(15, 'User14', '83617175fd8cf470d4af657a28def98e', 'User14@gmail.com', 'User14 Name', 2, NULL),
(16, 'User15', '83617175fd8cf470d4af657a28def98e', 'User15@gmail.com', 'User15 Name', 2, NULL),
(17, 'User16', '83617175fd8cf470d4af657a28def98e', 'User16@gmail.com', 'User16 Name', 2, NULL),
(18, 'User17', '83617175fd8cf470d4af657a28def98e', 'User17@gmail.com', 'User17 Name', 2, NULL),
(19, 'User18', '83617175fd8cf470d4af657a28def98e', 'User18@gmail.com', 'User18 Name', 2, NULL),
(20, 'User19', '83617175fd8cf470d4af657a28def98e', 'User19@gmail.com', 'User19 Name', 2, NULL),
(21, 'User20', '83617175fd8cf470d4af657a28def98e', 'User20@gmail.com', 'User20 Name', 2, NULL),
(22, 'User21', '83617175fd8cf470d4af657a28def98e', 'User21@gmail.com', 'User21 Name', 2, NULL),
(23, 'User22', '83617175fd8cf470d4af657a28def98e', 'User22@gmail.com', 'User22 Name', 2, NULL),
(24, 'User23', '83617175fd8cf470d4af657a28def98e', 'User23@gmail.com', 'User23 Name', 2, NULL),
(25, 'tinx5', 'tin', 'admin@admin.com', 'Toy HoÃ ng', 2, NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
